//
//  ViewController.swift
//  Allam_CalculatorApp
//
//  Created by Allam,Shiva Kumar on 2/8/23.
//

import UIKit

class ViewController: UIViewController {

    var number1:String = " "
    var number2:String = " "
    var operation:Character = " "
    @IBOutlet weak var resultOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonAC(_ sender: Any) {
        resultOutlet.text=""
                number1 = " "
                number2 = " "
                operation = " "
    }
    
    @IBAction func buttonC(_ sender: Any) {
        if(number2 != " "){
                    number2=String(number2[number2.startIndex..<number2.index(number2.endIndex,offsetBy: -1)])
                    
                    resultOutlet.text=number2
                    
                }
                
                else if(number1 != " "){
                    number1=String(number1[number1.startIndex..<number1.index(number1.endIndex,offsetBy: -1)])
                    resultOutlet.text=number1
                    
                }
    }
    
    @IBAction func buttonChange(_ sender: Any) {
        if(number2 != " "){
                   if(number2.contains(".")){
                       number2 = "\(-Double(number2)!)"
                       resultOutlet.text=number2
                   }
                   else{
                       number2 = "\(-Int(number2)!)"
                       resultOutlet.text=number2
                   }
                   
               }
               else if(number1 != " ") {
                   if(number1.contains(".")){
                       number1 = "\(-Double(number1)!)"
                       resultOutlet.text=number1
                   }
                   else{
                       number1 = "\(-Int(number1)!)"
                       resultOutlet.text=number1
                   }
               }
    }
    
    
    @IBAction func buttonDivide(_ sender: Any) {
        operation="/"
    }
    
    @IBAction func buttonSeven(_ sender: Any) {
        if (number1 == " " && operation == " " ){
                    number1="7"
                    resultOutlet.text="\(number1)"
                }else if(number1 != " " && operation == " " ){
                    number1=number1+"7"
                    resultOutlet.text="\(number1)"
                }
                else if(number2 == " " && operation != " "){
                    number2 = "7"
                    resultOutlet.text="\(number2)"
                }
                else if(number2 != " "){
                    number2=number2+"7"
                    resultOutlet.text="\(number2)"
                }
    }
    
    
    @IBAction func buttonEight(_ sender: Any) {
        if (number1 == " " && operation == " " ){
                   number1="8"
                   resultOutlet.text="\(number1)"
               }else if(number1 != " " && operation == " " ){
                   number1=number1+"8"
                   resultOutlet.text="\(number1)"
               }
               else if(number2 == " " && operation != " "){
                   number2 = "8"
                   resultOutlet.text="\(number2)"
               }
               else if(number2 != " "){
                   number2=number2+"8"
                   resultOutlet.text="\(number2)"
               }
    }
    
    
    @IBAction func buttonNine(_ sender: Any) {
        if (number1 == " " && operation == " " ){
                    number1="9"
                    resultOutlet.text="\(number1)"
                }else if(number1 != " " && operation == " " ){
                    number1=number1+"9"
                    resultOutlet.text="\(number1)"
                }
                else if(number2 == " " && operation != " "){
                    number2 = "9"
                    resultOutlet.text="\(number2)"
                }
                else if(number2 != " "){
                    number2=number2+"9"
                    resultOutlet.text="\(number2)"
                }
    }
    
    
    @IBAction func buttonMultiply(_ sender: Any) {
        operation="*"
    }
    
    
    @IBAction func buttonFour(_ sender: Any) {
        if (number1 == " " && operation == " " ){
                    number1="4"
                    resultOutlet.text="\(number1)"
                }else if(number1 != " " && operation == " " ){
                    number1=number1+"4"
                    resultOutlet.text="\(number1)"
                }
                else if(number2 == " " && operation != " "){
                    number2 = "4"
                    resultOutlet.text="\(number2)"
                }
                else if(number2 != " "){
                    number2=number2+"4"
                    resultOutlet.text="\(number2)"
                }
                
    }
    
    @IBAction func buttonFive(_ sender: Any) {
        if (number1 == " " && operation == " " ){
                   number1="5"
                   resultOutlet.text="\(number1)"
               }else if(number1 != " " && operation == " " ){
                   number1=number1+"5"
                   resultOutlet.text="\(number1)"
               }
               else if(number2 == " " && operation != " "){
                   number2 = "5"
                   resultOutlet.text="\(number2)"
               }
               else if(number2 != " "){
                   number2=number2+"5"
                   resultOutlet.text="\(number2)"
               }
    }
    
    @IBAction func buttonSix(_ sender: Any) {
        if (number1 == " " && operation == " " ){
                    number1="6"
                    resultOutlet.text="\(number1)"
                }else if(number1 != " " && operation == " " ){
                    number1=number1+"6"
                    resultOutlet.text="\(number1)"
                }
                else if(number2 == " " && operation != " "){
                    number2 = "6"
                    resultOutlet.text="\(number2)"
                }
                else if(number2 != " "){
                    number2=number2+"6"
                    resultOutlet.text="\(number2)"
                }
    }
    
    @IBAction func buttonMinus(_ sender: Any) {
        operation="-"
    }
    
    @IBAction func buttonOne(_ sender: Any) {
        if (number1 == " " && operation == " " ){
                    number1="1"
                    resultOutlet.text="\(number1)"
                }else if(number1 != " " && operation == " " ){
                    number1=number1+"1"
                    resultOutlet.text="\(number1)"
                }
                else if(number2 == " " && operation != " "){
                    number2 = "1"
                    resultOutlet.text="\(number2)"
                }
                else if(number2 != " "){
                    number2=number2+"1"
                    resultOutlet.text="\(number2)"
                }
    }
    @IBAction func buttonTwo(_ sender: Any) {
        if (number1 == " " && operation == " " ){
                   number1="2"
                   resultOutlet.text="\(number1)"
               }else if(number1 != " " && operation == " " ){
                   number1=number1+"2"
                   resultOutlet.text="\(number1)"
               }
               else if(number2 == " " && operation != " "){
                   number2 = "2"
                   resultOutlet.text="\(number2)"
               }
               else if(number2 != " "){
                   number2=number2+"2"
                   resultOutlet.text="\(number2)"
               }
    }
    @IBAction func buttonThree(_ sender: Any) {
        if (number1 == " " && operation == " " ){
                   number1="3"
                   resultOutlet.text="\(number1)"
               }else if(number1 != " " && operation == " " ){
                   number1=number1+"3"
                   resultOutlet.text="\(number1)"
               }
               else if(number2 == " " && operation != " "){
                   number2 = "3"
                   resultOutlet.text="\(number2)"
               }
               else if(number2 != " "){
                   number2=number2+"3"
                   resultOutlet.text="\(number2)"
               }
    }
    @IBAction func buttonPlus(_ sender: Any) {
        operation="+"
    }
    
    @IBAction func buttonZero(_ sender: Any) {
        if (number1 == " " && operation == " " ){
                   number1="0"
                   resultOutlet.text="\(number1)"
               }else if(number1 != " " && operation == " " ){
                   number1=number1+"0"
                   resultOutlet.text="\(number1)"
               }
               else if(number2 == " " && operation != " "){
                   number2 = "0"
                   resultOutlet.text="\(number2)"
               }
               else if(number2 != " "){
                   number2=number2+"0"
                   resultOutlet.text="\(number2)"
               }
    }
    @IBAction func buttonDot(_ sender: Any) {
        if(number1 == " " && operation == " "){
                   number1="0."
                   resultOutlet.text="\(number1)"
               }else if(number1 != " " && operation == " "){
                   number1=number1+"."
                   resultOutlet.text="\(number1)"
               }
               else if(number2 == " " && operation != " "){
                   number2="0."
                   resultOutlet.text="\(number2)"
               }else if(number2 != " "){
                   number2=number2+"."
                   resultOutlet.text="\(number2)"
               }
    }
    @IBAction func buttonPercentile(_ sender: Any) {
        operation="%"
    }
    @IBAction func buttonEquals(_ sender: Any) {
        switch operation{
                case "+" :
                    if(number1.contains(".")){
                        let value = "\(Double(number1)! + Double(number2)!)"
                        let ind=value.firstIndex(of: ".")!.utf16Offset(in: value)
                        let decrement = value[value.index(value.startIndex,offsetBy: ind+1)]
                        if(decrement != "0"){
                            resultOutlet.text = value
                        }
                        else{
                            resultOutlet.text = "\(Int(Double(number1)! + Double(number2)!))"
                        }
                        
                    }
                    else {
                        resultOutlet.text = "\(Int(number1)! + Int(number2)!)"
                    }
                    
                    
                case "-" :
                 
                    if(number1.contains(".")){
                        resultOutlet.text = "\(Double(number1)! - Double(number2)!)"
                    }
                    else {
                        resultOutlet.text = "\(Int(number1)! - Int(number2)!)"
                    }
                
                case "*" :
                    if(number1.contains(".")){
                        resultOutlet.text = "\(Double(number1)! * Double(number2)!)"
                    }
                    else {
                        resultOutlet.text = "\(Int(number1)! * Int(number2)!)"
                    }
                    
                case "/" :
                    if(number1.contains(".")){
                        resultOutlet.text = "\(Double(number1)! / Double(number2)!)"
                    }
                    else {
                        if(number2 == "0"){
                            resultOutlet.text = "Not a number"
                        }
                        else{
                            let val = "\(Double(number1)! / Double(number2)!)"
                            let firstInd=val.firstIndex(of: ".")!.utf16Offset(in: val)
                            let dec = val[val.index(val.startIndex,offsetBy: firstInd+1)]
                            if(dec != "0"){
                                resultOutlet.text = "\(round(Double(val)!*100000)/100000)"
                            }
                            else{
                                resultOutlet.text = "\(Int(number1)! / Int(number2)!)"
                            }
                        }
                        
                    }
                    
                case "%" :
                    
                    if(number1.contains(".")){
                        var val = Double(number1)!.truncatingRemainder(dividingBy: Double(number2)!)
                        resultOutlet.text = "\(round(val*10)/10)"
                    }
                    else {
                        resultOutlet.text = "\(Int(number1)! % Int(number2)!)"
                    }
                
                    
                default:
                    print("Invalid Input")
             
                
               }
    }
}

