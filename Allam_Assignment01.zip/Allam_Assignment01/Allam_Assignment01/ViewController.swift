//
//  ViewController.swift
//  Allam_Assignment01
//
//  Created by Allam,Shiva Kumar on 2/2/23.
//

import UIKit

class ViewController: UIViewController {
    
    //Declaration of firstNameOutlet
    @IBOutlet weak var firstNameOutlet: UITextField!
    
    //Declaration of lastNameOutlet
    @IBOutlet weak var lastNameOutlet: UITextField!
    
    //Declaration of yearOutlet
    @IBOutlet weak var yearOutlet: UITextField!
    
    //Declaration of detailslabel
    @IBOutlet weak var detailsLabel: UILabel!
    
    //Declaration of fullNameLabel
    @IBOutlet weak var fullNameLabel: UILabel!
    
    //Declaration of initialsLabel
    @IBOutlet weak var initialsLabel: UILabel!
    
    //Declaration of ageLabel
    @IBOutlet weak var ageLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    //print all of the fname and lname and dob
    
    @IBAction func submit(_ sender: Any) {
        fullNameLabel.text = "FullName : \(lastNameOutlet.text!),\(firstNameOutlet.text!)"
        
        initialsLabel.text = "Initials : \(lastNameOutlet.text!.first!),\(firstNameOutlet.text!.first!)"
        ageLabel.text = " Age : \(2023 - (Int(yearOutlet.text!) ?? 0))"
        detailsLabel.text = " Details"
    }
     
    //we also can reset
    @IBAction func reset(_ sender: Any) {
        firstNameOutlet.text=" "
        yearOutlet.text=" "
        detailsLabel.text=" "
        fullNameLabel.text=" "
        initialsLabel.text=" "
        ageLabel.text=" "
        lastNameOutlet.text=" "
    }
}

